# Base class representing a general bank account.
class BankAccount:
    def __init__(self, account_number, balance=0.0):
        # Encapsulated attributes using double underscores
        self.__account_number = account_number  
        self.__balance = balance

    def deposit(self, amount):
        if amount > 0:
            self.__balance += amount
            print(f"Deposited ${amount:.2f} to account {self.__account_number}.")
        else:
            print("Invalid deposit amount.")

    def withdraw(self, amount):
        if 0 < amount <= self.__balance:
            self.__balance -= amount
            print(f"Withdrew ${amount:.2f} from account {self.__account_number}.")
        else:
            print("Insufficient funds or invalid withdrawal amount.")

    def get_balance(self):
        return self.__balance

    def get_account_number(self):
        return self.__account_number


# SavingsAccount class inherits from BankAccount to demonstrate inheritance.
class SavingsAccount(BankAccount):
    def __init__(self, account_number, balance=0.0, interest_rate=0.02):
        # Call the base class constructor
        super().__init__(account_number, balance)
        # Additional encapsulated attribute for the interest rate
        self.__interest_rate = interest_rate

    def apply_interest(self):
        # Calculate interest based on current balance
        interest = self.get_balance() * self.__interest_rate
        # Deposit the interest into the account
        self.deposit(interest)
        print(f"Interest of ${interest:.2f} applied at rate {self.__interest_rate * 100:.1f}%.")

    def get_interest_rate(self):
        return self.__interest_rate


# Customer class to manage multiple accounts (composition).
class Customer:
    def __init__(self, name):
        self.name = name
        self.accounts = []

    def add_account(self, account):
        self.accounts.append(account)
        print(f"Account {account.get_account_number()} added for customer {self.name}.")

    def get_total_balance(self):
        # Sum the balance from all accounts owned by the customer.
        return sum(account.get_balance() for account in self.accounts)

    def display_accounts(self):
        print(f"\nCustomer: {self.name}")
        for account in self.accounts:
            print(f"Account Number: {account.get_account_number()}, Balance: ${account.get_balance():.2f}")


# Example usage of the classes.
def main():
    # Create a customer instance.
    customer1 = Customer("Alice")

    # Create a regular bank account and a savings account.
    regular_account = BankAccount("ACC123", 500.0)
    savings_account = SavingsAccount("SAV456", 1000.0, interest_rate=0.03)

    # Add accounts to the customer.
    customer1.add_account(regular_account)
    customer1.add_account(savings_account)

    # Perform some transactions.
    regular_account.deposit(200)
    regular_account.withdraw(100)
    savings_account.deposit(300)
    savings_account.withdraw(50)

    # Apply interest to the savings account.
    savings_account.apply_interest()

    # Display all account details for the customer.
    customer1.display_accounts()
    print(f"Total Balance for {customer1.name}: ${customer1.get_total_balance():.2f}")


if __name__ == "__main__":
    main()
